double div(double x,double y);
