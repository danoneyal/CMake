double sub(double x,double y);
