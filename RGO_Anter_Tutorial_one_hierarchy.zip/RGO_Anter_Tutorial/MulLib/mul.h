double mul(double x,double y);
