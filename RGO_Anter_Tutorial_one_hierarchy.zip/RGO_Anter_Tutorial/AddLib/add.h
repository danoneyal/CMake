double add(double x,double y);
