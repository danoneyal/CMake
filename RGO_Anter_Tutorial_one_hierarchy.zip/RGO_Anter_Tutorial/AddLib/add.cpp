#include <iostream>

// a hack square root calculation using simple operations
double add(double x,double y)
{  
  double result = x+y;
  std::cout << "Computing the add of " << x << " and "<< y <<" to be " << result << std::endl;
  return result;
}
